package br.com.curriculum;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void abrirDadosPessoais(View view){
        Intent it = new Intent(this, DadosPessoaisActivity.class);
        startActivity(it);

    }

    public void abrirDadosProfissionais(View view){
        Intent ap = new Intent(this, DadosProfissionaisActivity.class);
        startActivity(ap);
    }

    public void abrirContato(View view){
        Intent ac = new Intent(this, ContatosActivity.class);
        startActivity(ac);
    }

}
