package br.com.curriculum;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class ContatosActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_contatos);
    }
}
